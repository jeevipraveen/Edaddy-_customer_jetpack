package com.dawinder.btnjc.nav

object NavTitle {
    const val HOME = "Home"
    const val SEARCH = "Search"
    const val LIST = "List"
    const val PROFILE = "Profile"
}