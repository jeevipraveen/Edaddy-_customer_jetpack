package com.dawinder.btnjc.nav

enum class NavPath {
    HOME, SEARCH, LIST, PROFILE
}